
# Better Carts

### Quick Dettach and Reattach even when not in place.  Reduce, weight damage and have a buddy help push!


- Quick Dettach and Reattach with a configured key - even when not in perfect place
- Have a buddy help push - up to four players
- Remove cart damage
- server sync for multiplayer games. 

[Chat with me on Discord](https://discord.com/users/TastyChickenLegs#4818)

### About the Mod:
This is a combination of aedenthorn's quick cart and some of my own code.  Credit to Aedenthorn for creating Quick Cart


### Credits:

Aedenthorn for their public repository which taught me to mod and inspired my creations.  Much credit for everything

![screenshot](https://i.ibb.co/1MdbFK9/cartmenu.png)


### Configuration:

The config file is located in "<GameDirectory>\Bepinex\config" (You need to start the game at least once, with the mod installed to create the config file).

<b>To view or add items this mod affects:  </b>

See the images for a list of configurable items.


### List of supported objects:




### Installation: (manual)  


Extract DLL from zip file into "<GameDirectory>\Bepinex\plugins"  
Start the game.

### Version Information


1.0.6

- updated for Valheim 0.271.22


1.0.5

- Updated to work with Hildir's Request

1.0.4

- Fixed server error when synchronizing initial configuration



1.0.3

- Update to newest Valheim Patch .214.300


1.0.2

- update to newest Valheim patch .214.2 no other changes.

1.0.1

- fixed bug with hardcoded "V" in player GUI

1.0.0

- initial release
##	Now for the shameless plug

> ### My Other Mods:
>>* [Drop More Loot](https://valheim.thunderstore.io/package/TastyChickenLegs/DropMoreLoot/)
>>* [Automatic Fermenters](https://valheim.thunderstore.io/package/TastyChickenLegs/AutomaticFermenters/)
>>* [No Smoke Stay Lit](https://valheim.thunderstore.io/package/TastyChickenLeg/NoSmokeStayLit/)
>>* [No Smoke Simplified](https://valheim.thunderstore.io/package/TastyChickenLegs/NoSmokeSimplified/)
>>* [Honey Please](https://valheim.thunderstore.io/package/TastyChickenLegs/HoneyPlease/)
>>* [Automatic Fuel](https://valheim.thunderstore.io/package/TastyChickenLeg/AutomaticFuel/)
>>* [Forsaken Powers Plus](https://valheim.thunderstore.io/package/TastyChickenLeg/ForsakenPowersPlus/)
>>* [Recycle Plus](https://valheim.thunderstore.io/package/TastyChickenLeg/RecyclePlus/)
>>* [Blast Furnace Takes All](https://valheim.thunderstore.io/package/TastyChickenLeg/BlastFurnaceTakesAll/)
>>* [Timed Torches Stay Lit](https://valheim.thunderstore.io/package/TastyChickenLeg/TimedTorchesStayLit/)
>>* [Automatic Fermenters](https://valheim.thunderstore.io/package/TastyChickenLegs/AutomaticFermenters/)
